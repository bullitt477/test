NorbCo Resourxes - Bordered Clear Glass

This resource pack consists of textures inspired by Clear Glass Borderless & Clear Ice (https://xaphex.github.io/).

NorbCo Resourxes - Bordered Clear Glass by Creative Norb is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. See https://creativecommons.org/licenses/by-nc-sa/4.0/ for details.

Questions? Send them to ResourcePacks@NorbCo.net.

CHANGE LOG:

v0.0.1, 2019-03-22:
1. Initial version